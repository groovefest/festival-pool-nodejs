var api = "http://poolhost:8117";

var email = "support@poolhost.com";
var telegram = "https://t.me/YourPool";
var discord = "https://discordapp.com/invite/YourPool";

var marketCurrencies = ["{symbol}-BTC", "{symbol}-USD", "{symbol}-EUR", "{symbol}-CAD"];

var blockchainExplorer = "http://chainradar.com/{symbol}/block/{id}";
var transactionExplorer = "http://chainradar.com/{symbol}/transaction/{id}";

var themeCss = "themes/default.css";
var defaultLang = 'en';